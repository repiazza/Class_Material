#ifndef CALC_H
#define CALC_H

void vSoma(int iA, int iB, int *piResultado);

#endif
