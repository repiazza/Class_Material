#ifndef LOG_H
#define LOG_H

void vLog(const char *pcMensagem);

#endif
