#include <stddef.h>
#include "calc.h"

void vSoma(int iA, int iB, int *piResultado)
{
  if (piResultado == NULL)
    return;

  *piResultado = iA + iB;
}
