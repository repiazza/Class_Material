#include <stdio.h>
#include "calc.h"
#include "log.h"

int main(void)
{
  int iResultado;

  iResultado = 0;

  vLog("Iniciando calculadora");
  vSoma(10, 5, &iResultado);
  printf("Resultado: %d\n", iResultado);
  vLog("Calculadora finalizada");

  return 0;
}
