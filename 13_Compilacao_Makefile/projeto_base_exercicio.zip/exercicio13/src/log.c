#include <stdio.h>
#include "log.h"

void vLog(const char *pcMensagem)
{
  if (pcMensagem == NULL)
    return;

  printf("[LOG] %s\n", pcMensagem);
}
